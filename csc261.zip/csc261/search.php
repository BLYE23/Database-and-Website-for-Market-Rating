<?php
require_once ('link.php');

$UID = $_POST['UID'];

if($UID>26){
  $result_p = FALSE;
  }
  else{
  // Prepare a select statement
  $query_p = "SELECT Product.Pname, RateforProduct.Prate, Product.Pid
  FROM User, RateforProduct, Product WHERE User.UID = $UID AND Product.Pid = RateforProduct.Pid AND RateforProduct.UID = $UID";
  $result_p = $conn->query($query_p)or die( mysqli_error($conn));
  
}


?>

<html>
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>GoodSearch</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
  </head>
    <body>
    <header>
      <h1>GoodSearch</h1>
    </header>
    <nav>
        <ul>
          <li>
            <a href="index.html"><h3>About</h3></a>
          </li>
          <li>
            <a href="query.html"><h3>query</h3></a>
          </li>
          <li>
            <a href="db.html"><h3>database</h3></a>
          </li>
          <li>
            <a class="active" ,href="#"><h3>insert</h3></a>
          </li>
          <li>
            <a href="search.html"><h3>search</h3></a>
          </li>
        </ul>
      </nav>
      <article>
          
        <table>

            <?php if ($result_p === FALSE){
              echo "Invalid input";}
              else{
            while ($row = mysqli_fetch_array($result_p)): ?>
                <?php $PName = $row['Pname']; ?>
                <?php $Prate = $row['Prate']; ?>
                <?php $Pid = $row['Pid']; ?>
                <tr>
            <th>Product ID</th>
            <th>Product Name</th>
            <th>Your Rating</th>



        </tr>


                
                <tr>
                    <td><?php echo $Pid; ?></td>

                    <td><?php echo $PName; ?></td>

                    <td><?php echo $Prate; ?></td>
                </tr>


            <?php endwhile; 
            
          
            }?>
        </table>
            </article>
    </body>
</html>